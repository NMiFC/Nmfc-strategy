# Operations

## Youth Labor
- $12/hr wage
- Annual rotation
- Candle production = dignity of care

## Kiosk Protocol
- “We heat ourselves” signage
- 24/7 trust-based pickup
- QR links: issue reporting, donations

## Facilities
- 301 N Michigan Ave (public HQ)
- 3-acre site (processing/storage)

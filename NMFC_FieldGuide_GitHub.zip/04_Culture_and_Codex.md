# Culture & Codex

## Mantras & Ethics
- “We heat ourselves.”
- “Caring is resistance.”
- “Burn bright. Stay free.”

## Candles & Murals
- Rotating seasonal quotes
- Mural series funded annually
- Cultural Appendix (Z1–Z3)

## Rituals
- First Flame
- BTC Bonus Day
- Winter Wood Drop

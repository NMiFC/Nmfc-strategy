# Governance Model

## FID Council
- Flame: Culture and narrative
- Infrastructure: Physical systems
- Distribution: Access and equity
- Executives rotate out after BTC yield reaches independence threshold (4% rule)

## Mission Anchor
- Council of Former Executives
- Can pause actions, trigger reviews

## Cooperative Transition
- Begins Year 10
- Sweat equity → ownership

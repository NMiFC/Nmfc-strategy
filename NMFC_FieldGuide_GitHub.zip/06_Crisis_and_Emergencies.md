# Crisis & Emergency Protocols

## Covered Events
- BTC theft or loss
- Death or incapacitation of steward
- Natural disaster
- Legal interference
- Co-op collapse

## Response
- Anchor steps in for lost FID
- No BTC used to replace BTC
- Public declaration + 30-day review cycle

# Appendices Summary

## Appendix A: BTC Multisig Protocol
- 2-of-3 signing
- Flame, Infra, Distribution

## Appendix B: Co-op Onboarding Manual
- 700-hour path
- Voting share on entry

## Appendix C: Kiosk Messaging
- Care Code
- QR zone and mural etiquette

## Appendix D: Warmth Referral System
- Partner-vouch only
- 2/month cap per org

## Appendix E: Transparency Report Template
- BTC growth, candles sold, homes served

## Appendix F: FID Onboarding/Exit
- 3-year terms, BTC exit logic, temp stewarding

## Appendix G: BTC Ledger Format
- BTC bonuses tracked annually

## Appendix H: BTC Bonus Ledger
- Template with example values

## Appendix I: DAO-lite Proposal System
- 66% vote, 7-day review, Anchor pause rights

## Appendix J: Shared Crisis Protocol
- Natural disaster, BTC theft, leadership loss

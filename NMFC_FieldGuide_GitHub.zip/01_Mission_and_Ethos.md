# Mission & Ethos

> "We believe in sovereignty over dependency. Mutual aid over charity. Care, fire, and work that doesn’t flinch."

NMFC exists to eliminate heat insecurity in Northern Michigan through decentralized production, youth-led programs, and BTC-backed sustainability.

**Core Values:**
- Sovereignty
- Care
- Permanence
- Trust
- Intergenerational Stewardship

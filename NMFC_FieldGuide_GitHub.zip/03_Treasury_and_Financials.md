# Treasury & Financials

## Profit Allocation
- 40% BTC Reserve
- 20% Northern Warmth Initiative
- 15% Location Share
- 10% Cash Reserve (capped at $57,600)
- 10% Owner Bonus (BTC only)
- 5% Non-owner Youth Bonus Pool

## BTC Surplus Policy (>$1M)
- Use BTC **yield** to seed new entities (max 10 years)
- Return 1% BTC-based revenue annually
- NMFC retains budget & appointment oversight
- Can exit by repaying BTC in full (1 BTC = 1 BTC)

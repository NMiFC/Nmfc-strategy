# Northern Michigan Fire Co – Field Guide

This is the operational, ethical, and cultural blueprint for NMFC.

> “Use this, adapt this — but don’t hollow it out. Burn bright.”

## Summary
This Field Guide exists to build and protect something rare: a community-owned, anti-extractive, intergenerational fire company that fights heat insecurity with sovereignty, care, and permanence.

**Guardrails:**
- BTC can’t be sold
- FID cannot operate unchecked
- Workers can’t be exploited
- Profits can’t drift

**Flexibility:**
- Codex can evolve
- Rituals rotate
- Treasury adapts
- Power passes through stewardship
